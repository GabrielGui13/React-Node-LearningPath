import { LanguageType } from "./types";

export const textDataFR: LanguageType = {
  language: "fr",
  loginScreen: {
    welcome: "Bienvenue, ici vous pourrez suivre vos tickets Interas.",
    loginForm: {
      email: "Email",
      password: "Mot de passe",
      emailPlaceholder: "Entrez votre email",
      passwordPlaceholder: "Entrez votre mot de passe",
      sendButton: "Se connecter",
    },
    forgotPassword: "Mot de passe oublié ?",
    registerLink: {
      text: "Vous n'avez pas encore de compte ?",
      link: "Inscrivez-vous",
    },
    loginWithInviteCode: "Se connecter avec un code d'invitation",
    generateAccessCode: "Générer un code d'accès",
    forgotPasswordComponent: {
      title: "Mot de passe oublié ?",
      subtitle:
        "Entrez votre email pour que nous puissions vous envoyer les instructions pour réinitialiser votre mot de passe.",
      email: "Email",
      emailPlaceholder: "Entrez votre email",
      sendButton: "Envoyer",
      supportText: "Je ne me souviens pas de mon email, contactez le",
      supportLink: "support",
    },
    forgotPasswordFeedback: {
      title: "Email envoyé avec succès",
      subtitle:
        "Pour finaliser la modification du mot de passe, consultez votre email et suivez les instructions.",
      button: "Compris",
    },
  },
  registerScreen: {
    title: "Demander",
    titleBold: "un compte.",
    form: {
      name: "Nom et prénom",
      namePlaceholder: "Entrez votre nom et prénom",
      password: "Mot de passe",
      passwordPlaceholder: "Entrez votre mot de passe",
      email: "Email",
      emailPlaceholder: "Entrez votre email",
      company: "Entreprise",
      companyPlaceholder: "Entrez votre entreprise",
      businessUnit: "Unité/Magasin",
      businessUnitPlaceholder: "Entrez votre unité/magasin",
      phone: "Téléphone",
      phonePlaceholder: "Entrez votre téléphone",
      button: "Demander mon compte",
    },
    registerFeedback: {
      title: "Email envoyé avec succès",
      subtitle:
        "Maintenant, il ne vous reste plus qu'à attendre, dans un délai de 72 heures, notre équipe examinera votre inscription et activera votre compte.",
      button: "Compris",
    }
  }
};
