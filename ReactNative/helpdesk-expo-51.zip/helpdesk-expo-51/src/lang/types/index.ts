export type LanguageNameType = 'pt' | 'en' | 'es' | 'fr';

export type LanguageType = {
	language: LanguageNameType | string,
	loginScreen: {
		welcome: string;
		loginForm: {
			email: string;
			password: string;
			emailPlaceholder: string;
			passwordPlaceholder: string;
			sendButton: string;
		};
		forgotPassword: string;
		registerLink: {
			text: string;
			link: string;
		};
		loginWithInviteCode: string;
		generateAccessCode: string;
		forgotPasswordComponent: {
			title: string;
			subtitle: string;
			email: string;
			emailPlaceholder: string;
			sendButton: string;
			supportText: string;
			supportLink: string;
		};
		forgotPasswordFeedback: {
			title: string;
			subtitle: string;
			button: string;
		};
	}
	registerScreen: {
		title: string;
		titleBold: string;
		form: {
			name: string;
			namePlaceholder: string;
			password: string;
			passwordPlaceholder: string;
			email: string;
			emailPlaceholder: string;
			company: string;
			companyPlaceholder: string;
			businessUnit: string;
			businessUnitPlaceholder: string;
			phone: string;
			phonePlaceholder: string;
			button: string;
		},
		registerFeedback: {
			title: string;
			subtitle: string;
			button: string;
		}
	}
}