import { LanguageType } from "./types";

export const textDataPT: LanguageType = {
	language: "pt",
	loginScreen: {
		welcome: "Bem vindos, aqui você vai poder acompanhar os seus chamados da Interas.",
		loginForm: {
			email: "Email",
			password: "Senha",
			emailPlaceholder: "Informe o email",
			passwordPlaceholder: "Informe a senha",
			sendButton: "Entrar",
		},
		forgotPassword: "Esqueceu a senha?",
		registerLink: {
			text: "Ainda não tem uma conta?",
			link: "Cadastre-se",
		},
		loginWithInviteCode: "Entrar com código de convite",
		generateAccessCode: "Gerar código de acesso",
		forgotPasswordComponent: {
			title: "Esqueceu sua senha?",
			subtitle: "Informe seu email para enviarmos as instruções de como redefinir sua senha.",
			email: "Email",
			emailPlaceholder: "Informe o email",
			sendButton: "Enviar",
			supportText: "Não lembro meu email, fale com o",
			supportLink: "suporte",
		},
		forgotPasswordFeedback: {
			title: "Email enviado com sucesso",
			subtitle: "Para finalizar a alteração de senha, entre em contato com o seu email e siga as instruções.",
			button: "Entendi",
		},
	},
	registerScreen: {
		title: "Solicitar",
		titleBold: "uma conta.",
		form: {
			name: "Nome e sobrenome",
			namePlaceholder: "Informe o nome e sobrenome",
			password: "Senha",
			passwordPlaceholder: "Informe a sua senha",
			email: "Email",
			emailPlaceholder: "Informe o email",
			company: "Empresa",
      companyPlaceholder: "Informe a sua empresa",
      businessUnit: "Unidade/Loja",
      businessUnitPlaceholder: "Informe a sua unidade/loja",
      phone: "Telefone",
			phonePlaceholder: "Digite seu telefone",
			button: "Solicitar minha conta",
		},
		registerFeedback: {
			title: "Email enviado com sucesso",
			subtitle: "Agora é só esperar, dentro de 72 horas nossa equipe revisará seu cadastro e habilitará sua conta.",
			button: "Entendi"
		}
	}
}