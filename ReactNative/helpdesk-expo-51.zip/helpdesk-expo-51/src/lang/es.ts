import { LanguageType } from "./types";

export const textDataES: LanguageType = {
  language: "es",
  loginScreen: {
    welcome: "Bienvenidos, aquí podrás seguir tus tickets de Interas.",
    loginForm: {
      email: "Correo electrónico",
      password: "Contraseña",
      emailPlaceholder: "Introduce tu correo electrónico",
      passwordPlaceholder: "Introduce tu contraseña",
      sendButton: "Iniciar sesión",
    },
    forgotPassword: "¿Olvidaste tu contraseña?",
    registerLink: {
      text: "¿Aún no tienes una cuenta?",
      link: "Regístrate",
    },
    loginWithInviteCode: "Iniciar sesión con invitación",
    generateAccessCode: "Generar código de acceso",
    forgotPasswordComponent: {
      title: "¿Olvidaste tu contraseña?",
      subtitle:
        "Introduce tu correo electrónico para que podamos enviarte las instrucciones para restablecer tu contraseña.",
      email: "Correo electrónico",
      emailPlaceholder: "Introduce tu correo electrónico",
      sendButton: "Enviar",
      supportText: "No recuerdo mi correo electrónico, contacta con el",
      supportLink: "soporte",
    },
    forgotPasswordFeedback: {
      title: "Correo electrónico enviado con éxito",
      subtitle:
        "Para finalizar el cambio de contraseña, consulta tu correo electrónico y sigue las instrucciones.",
      button: "Entendido",
    },
  },
  registerScreen: {
    title: "Solicitar",
    titleBold: "una cuenta.",
    form: {
      name: "Nombre y apellidos",
      namePlaceholder: "Introduce tu nombre y apellidos",
      password: "Contraseña",
      passwordPlaceholder: "Introduce tu contraseña",
      email: "Correo electrónico",
      emailPlaceholder: "Introduce tu correo electrónico",
      company: "Empresa",
      companyPlaceholder: "Introduce tu empresa",
      businessUnit: "Unidad/Tienda",
      businessUnitPlaceholder: "Introduce tu unidad/tienda",
      phone: "Teléfono",
      phonePlaceholder: "Introduce tu teléfono",
      button: "Solicitar mi cuenta",
    },
    registerFeedback: {
      title: "Correo electrónico enviado con éxito",
      subtitle:
        "Ahora solo tienes que esperar, en un plazo de 72 horas nuestro equipo revisará tu registro y habilitará tu cuenta.",
      button: "Entendido",
    },
  }
};
