import { LanguageType } from "./types";

export const textDataEN: LanguageType = {
  language: "en",
  loginScreen: {
    welcome: "Welcome, here you will be able to track your Interas tickets.",
    loginForm: {
      email: "Email",
      password: "Password",
      emailPlaceholder: "Enter your email",
      passwordPlaceholder: "Enter your password",
      sendButton: "Login",
    },
    forgotPassword: "Forgot your password?",
    registerLink: {
      text: "Don't have an account yet?",
      link: "Sign up",
    },
    loginWithInviteCode: "Login with invite code",
    generateAccessCode: "Generate access code",
    forgotPasswordComponent: {
      title: "Forgot your password?",
      subtitle:
        "Enter your email so we can send you instructions on how to reset your password.",
      email: "Email",
      emailPlaceholder: "Enter your email",
      sendButton: "Send",
      supportText: "I don't remember my email, contact",
      supportLink: "support",
    },
    forgotPasswordFeedback: {
      title: "Email sent successfully",
      subtitle:
        "To complete the password change, check your email and follow the instructions.",
      button: "Got it",
    },
  },
  registerScreen: {
    title: "Request",
    titleBold: "an account.",
    form: {
      name: "Name and surname",
      namePlaceholder: "Enter your name and surname",
      password: "Password",
      passwordPlaceholder: "Enter your password",
      email: "Email",
      emailPlaceholder: "Enter your email",
      company: "Company",
      companyPlaceholder: "Enter your company",
      businessUnit: "Unit/Store",
      businessUnitPlaceholder: "Enter your unit/store",
      phone: "Phone",
      phonePlaceholder: "Enter your phone",
      button: "Request my account",
    },
    registerFeedback: {
      title: "Email sent successfully",
      subtitle:
        "Now just wait, within 72 hours our team will review your registration and enable your account.",
      button: "Got it",
    },
  },
};
