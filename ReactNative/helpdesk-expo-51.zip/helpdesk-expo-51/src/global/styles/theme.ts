export const theme = {
  colors: {
    primary: '#0A2D4A',
    primary_light: '#002A6F',

    text: '#1A202C',
    text_primary: '#0A2D4A',
    text_primary_light: '#002A6F',
    text_black: '#000000',
    text_white: '#FFFFFF',
    text_muted: '#7B7B7B',

    background_dark: '#1A202C',
    background_light: '#FFFFFF',

    button: '#0A2D4A',
    button_primary: '#0A2D4A',
    button_dark: '#1A202C',
    button_light: '#EBEBEA',
    button_secondary: '#3B3A4D',

    border: "#ABABAB",
    border_primary: "#0A2D4A",
    border_primary_light: "#002A6F",

    success: '#12a454',
    success_light: '#93D3B0',

    info: '#024181',
    info_light: 'rgba(30, 144, 255, 0.5)',

    warning: '#97790E',
    warning_light: '#F5E29E',

    error: '#FF002B',
    error_light: '#FFA0B0',


    shape: '#FFFFFF',
    title: '#363f5f',
    text_dark: '#37352F',
    text_light: '#d8d8d8',
    background: '#101010',
    line_dark: '#37352F',
    light_border: '#E5E5E5',

    text_title: '#1E232C',
    text_span: '#97A0AB',

    text_span_foreground: '#7D7C78',
  },

  fonts: {
    poppins: {
      thin: 'Poppins_100Thin',
      light: 'Poppins_300Light',
      regular: 'Poppins_400Regular',
      medium: 'Poppins_500Medium',
      bold: 'Poppins_700Bold',
    },
  },
}
