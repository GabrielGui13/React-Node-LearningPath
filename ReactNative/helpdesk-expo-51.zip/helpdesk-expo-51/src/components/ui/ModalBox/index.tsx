import { useEffect, useRef, useState } from "react";
import {
  Modal,
  ModalProps,
  TouchableWithoutFeedback,
  View,
  ViewProps,
} from "react-native";
import { Portal } from "react-native-portalize";
import { ModalBoxContainer } from "./styles";

export interface ModalBoxProps extends Omit<ModalProps, "visible" | "transparent" | "animationType" | "style"> {
  open: boolean;
  setOpen: React.Dispatch<React.SetStateAction<boolean>>;
  modalProps?: Pick<ViewProps, "style">;
}

export const ModalBox = ({
  children,
  open,
  setOpen,
  modalProps,
  ...props
}: ModalBoxProps) => {
  const [innerClose, setInnerClose] = useState(true);
  const modalRef = useRef<Modal>(null);

  const closeModal = () => {
    setInnerClose(false);
    setOpen((prev) => !prev);
  };

  useEffect(() => {
    if (open && !innerClose) {
      setInnerClose((prev) => !prev);
    }
  }, [open]);

  return (
    <Portal>
      <Modal
        ref={modalRef}
        visible={open && innerClose}
        transparent={true}
				animationType="fade"
        {...props}
      >
        <TouchableWithoutFeedback style={{ flex: 1 }} onPress={closeModal}>
          <ModalBoxContainer
            style={[{
              backgroundColor: "#000000bb",
            }, modalProps?.style]}
          >
            <TouchableWithoutFeedback onPress={(e) => e.stopPropagation()}>
              {children}
            </TouchableWithoutFeedback>
          </ModalBoxContainer>
        </TouchableWithoutFeedback>
      </Modal>
    </Portal>
  );
};
