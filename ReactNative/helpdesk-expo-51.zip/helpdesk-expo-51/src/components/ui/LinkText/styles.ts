import styled from "styled-components/native";

export const LinkTextPressable = styled.Pressable`
	
`

export const LinkTextContent = styled.Text`
	
`