import { ViewProps } from "react-native";
import {
  MessageBoxContainer,
  MessageBoxContentWrapper,
  MessageBoxTitleWrapper,
  MessageBoxTextWrapper,
} from "./styles";
import { BaseText } from "../BaseText";
import { useTheme } from "styled-components";
import { MaterialIcons } from "@expo/vector-icons";

type MessageBoxType = "success" | "error" | "warning" | "info";
type IconType = "check-circle" | "error" | "warning" | "info";

interface MessageBoxProps extends ViewProps {
  type: MessageBoxType;
  title: string | JSX.Element;
  subtitle?: string | JSX.Element;
  message?: string | JSX.Element;
  children?: JSX.Element;
  backgroundColor?: string;
  textColor?: string;
  iconColor?: string;
}

export const MessageBox = ({
  type,
  title,
  subtitle,
  message,
  children,
	textColor,
	backgroundColor,
	iconColor,
  ...props
}: MessageBoxProps) => {
  const theme = useTheme();

  const typeOptions: {
    backgroundColor: string;
    color: string;
    icon: IconType | string;
  } = {
    success: {
      backgroundColor: theme.colors.success_light,
      color: theme.colors.success,
      icon: "check-circle",
    },
    error: {
      backgroundColor: theme.colors.error_light,
      color: theme.colors.error,
      icon: "error",
    },
    warning: {
      backgroundColor: theme.colors.warning_light,
      color: theme.colors.warning,
      icon: "warning",
    },
    info: {
      backgroundColor: theme.colors.info_light,
      color: theme.colors.info,
      icon: "info",
    },
  }[type];

  return (
    <MessageBoxContainer
      style={{ backgroundColor: backgroundColor ? backgroundColor : typeOptions.backgroundColor }}
      {...props}
    >
      <MessageBoxTitleWrapper>
        <MaterialIcons
          color={iconColor ? iconColor : typeOptions.color}
          size={32}
          name={typeOptions.icon as IconType}
        />
        <BaseText size="sm" color={textColor ? textColor : typeOptions.color} weight="bold">
          {title}
        </BaseText>
      </MessageBoxTitleWrapper>
      <MessageBoxTextWrapper
        style={{ display: subtitle || message ? "flex" : "none" }}
      >
        <BaseText size="xs" weight="medium" color={textColor ? textColor : typeOptions.color}>
          {subtitle}
        </BaseText>
        <BaseText size="xs" weight="bold" color={textColor ? textColor : typeOptions.color}>
          {message}
        </BaseText>
      </MessageBoxTextWrapper>
      <MessageBoxContentWrapper style={{ display: children ? "flex" : "none" }}>
        {children}
      </MessageBoxContentWrapper>
    </MessageBoxContainer>
  );
};
