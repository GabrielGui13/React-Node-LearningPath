import styled from "styled-components/native";

export const MessageBoxContainer = styled.View`
	width: 100%;
	border-radius: 16px;
	padding: 16px;
	gap: 10px;
`

export const MessageBoxTitleWrapper = styled.View`
	gap: 10px;
	flex-direction: row;
	align-items: center;
`

export const MessageBoxTextWrapper = styled.View`
	gap: 10px;
	margin-left: 42px;
`

export const MessageBoxContentWrapper = styled.View`
	gap: 10px;
	margin-left: 42px;
`