import { TextInputProps } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import {
  InputContainer,
  InputError,
  InputErrorWrapper,
  InputField,
  InputLabel,
  InputWrapper,
} from "./styles";
import { parseWidthSize, WidthSizeType } from "../../../utils/parseWidthSize";
import { useTheme } from "styled-components";

export interface InputProps extends TextInputProps {
  size?: WidthSizeType;
  label?: string;
  error?: string;
  icon?: () => JSX.Element;
  showPassword?: boolean;
  onShowPassword?: () => void;
}

export const Input = ({
  size = "xl",
  label,
  error,
  icon,
  showPassword,
  onShowPassword,
  ...props
}: InputProps) => {
  const theme = useTheme();
  const password = showPassword !== undefined;

  return (
    <InputContainer style={{ width: parseWidthSize(size) }}>
      <InputLabel style={{ display: label ? "flex" : "none" }}>
        {label}
      </InputLabel>
      <InputWrapper style={{ borderColor: error ? theme.colors.error : theme.colors.border }}>
        {icon && icon()}
        <InputField {...props} keyboardType="ascii-capable" secureTextEntry={password && !showPassword} />
        <Ionicons
          onPress={onShowPassword}
          style={{ display: password ? "flex" : "none" }}
          name={`${showPassword ? "eye" : "eye-off"}`}
          color={theme.colors.border}
          size={25}
        />
      </InputWrapper>
      <InputErrorWrapper style={{ opacity: error ? 1 : 0 }}>
        <Ionicons name="warning" color={theme.colors.error} size={15} />
        <InputError>{error}</InputError>
      </InputErrorWrapper>
    </InputContainer>
  );
};
