import Constants from "expo-constants"
import { Platform } from "react-native"
import styled from "styled-components/native"

const statusBarHeight = Constants.statusBarHeight + 16

export const HeaderContainer = styled.View`
	background-color: ${({ theme }) => theme.colors.background_light};
	width: 100%;
	flex-direction: row;
	justify-content: space-between;
	align-items: center;
	padding: 5%;
	padding-top: ${statusBarHeight}px;
	padding-bottom: ${statusBarHeight/4}px;;
	border-bottom-width: 1px;
	border-bottom-color: ${({ theme }) => theme.colors.border};
	z-index: 99;
`

export const HeaderBackButton = styled.TouchableOpacity`
	flex-direction: row;
	align-items: center;
	gap: 3px;
`

export const HeaderIcon = styled.Image`
	width: 37px;
	height: 37px;
`