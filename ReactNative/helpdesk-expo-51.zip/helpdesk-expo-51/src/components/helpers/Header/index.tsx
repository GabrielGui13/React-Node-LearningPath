import { Image } from "react-native"
import { HeaderBackButton, HeaderContainer, HeaderIcon } from "./styles"
import { BaseText } from "../../ui/BaseText"
import { MaterialIcons } from "@expo/vector-icons"
import { useRouter } from "../../../hooks/useRouter"
import { useTheme } from "styled-components"

export const Header = () => {
	const theme = useTheme()
	const { navigation } = useRouter()
	
	const handleGoBack = () => {
		navigation.goBack()
	}
	
	return (
		<HeaderContainer>
			<HeaderBackButton activeOpacity={0.5} onPress={handleGoBack}>
				<MaterialIcons name="arrow-back-ios" size={20} />
				<BaseText>Voltar</BaseText>
			</HeaderBackButton>
			<HeaderIcon source={require('../../../assets/image/interas-icon-blue.png')} />
		</HeaderContainer>
	)
}