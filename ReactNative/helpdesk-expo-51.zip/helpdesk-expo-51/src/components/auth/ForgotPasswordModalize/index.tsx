import { Portal } from "react-native-portalize";
import { Modalize, ModalizeProps } from "react-native-modalize";
import { forwardRef } from "react";
import { BaseText } from "../../ui/BaseText";
import { ForgotPasswordModalizeContainer } from "./styles";
import { useTheme } from "styled-components/native";
import { Input } from "../../ui/Input";
import { PrimaryButton } from "../../ui/PrimaryButton";
import { View } from "react-native";
import { LinkText } from "../../ui/LinkText";
import { useLanguage } from "../../../hooks/useLanguage";

interface ForgotPasswordModalizeProps extends ModalizeProps {
	
}

export const ForgotPasswordModalize = forwardRef(
  ({ onClose, ...props }: ForgotPasswordModalizeProps, ref) => {
		const theme = useTheme()
		const { textData } = useLanguage()
		
		const sendEmailHandler = () => {
			onClose && onClose()
		}
		
    return (
      <Portal>
        <Modalize
          {...props}
          ref={ref}
          scrollViewProps={{ alwaysBounceVertical: false }}
					adjustToContentHeight
					// snapPoint={400}
          // modalHeight={400}
					// alwaysOpen={400}
        >
          <ForgotPasswordModalizeContainer>
						<View style={{ gap: 10 }}>
							<BaseText size="md" color={theme.colors.text_primary_light} weight="bold">{textData.loginScreen.forgotPasswordComponent.title}</BaseText>
							<BaseText size="sm">{textData.loginScreen.forgotPasswordComponent.subtitle}</BaseText>
							<Input label={textData.loginScreen.forgotPasswordComponent.email} placeholder={textData.loginScreen.forgotPasswordComponent.emailPlaceholder} size="full" />
						</View>
						<View style={{ gap: 10 }}>
							<PrimaryButton size="full" onPress={sendEmailHandler}>{textData.loginScreen.forgotPasswordComponent.sendButton}</PrimaryButton>
							<View style={{ flexDirection: "row", justifyContent: "center" }}>
								<BaseText size={"xs"}>{textData.loginScreen.forgotPasswordComponent.supportText}{" "}</BaseText>
								<LinkText size={"xs"} color={theme.colors.text_primary_light} weight="bold" >{textData.loginScreen.forgotPasswordComponent.supportLink}</LinkText>
							</View>
						</View>
					</ForgotPasswordModalizeContainer>
        </Modalize>
      </Portal>
    );
  },
);
