import { View } from "react-native";
import { BaseText } from "../../ui/BaseText";
import { ModalBox, ModalBoxProps } from "../../ui/ModalBox";
import {
  ForgotPasswordFeedbackModalContainer,
  ForgotPasswordFeedbackModalTextWrapper,
} from "./styles";
import { useTheme } from "styled-components";
import { PrimaryButton } from "../../ui/PrimaryButton";
import { useLanguage } from "../../../hooks/useLanguage";

interface ForgotPasswordFeedbackModalProps extends ModalBoxProps {}

export const ForgotPasswordFeedbackModal = ({
  open,
  setOpen,
  ...props
}: ForgotPasswordFeedbackModalProps) => {
  const theme = useTheme();
  const { textData } = useLanguage()

  return (
    <ModalBox
      open={open}
      setOpen={setOpen}
      modalProps={{
        style: {
          padding: "5%",
        },
      }}
      {...props}
    >
      <ForgotPasswordFeedbackModalContainer>
        <ForgotPasswordFeedbackModalTextWrapper>
          <BaseText size="sm" color={theme.colors.text_black} weight="medium">
            {textData.loginScreen.forgotPasswordFeedback.title}
          </BaseText>
          <BaseText size="xs" color={theme.colors.text_muted} weight="medium">
            {textData.loginScreen.forgotPasswordFeedback.subtitle}
          </BaseText>
        </ForgotPasswordFeedbackModalTextWrapper>
        <PrimaryButton onPress={() => setOpen(false)} size="full">
          {textData.loginScreen.forgotPasswordFeedback.button}
        </PrimaryButton>
      </ForgotPasswordFeedbackModalContainer>
    </ModalBox>
  );
};
