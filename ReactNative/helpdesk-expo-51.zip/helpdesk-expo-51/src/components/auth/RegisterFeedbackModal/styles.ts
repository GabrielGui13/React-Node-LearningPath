import styled from "styled-components/native";

export const RegisterFeedbackModalContainer = styled.View`
	width: 100%;
	background-color: ${({ theme }) => theme.colors.background_light};
	border-radius: 8px;
	padding: 7%;
	gap: 30px;
`

export const RegisterFeedbackModalTextWrapper = styled.View`
	gap: 15px;
`