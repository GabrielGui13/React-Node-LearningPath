import { View } from "react-native";
import { BaseText } from "../../ui/BaseText";
import { ModalBox, ModalBoxProps } from "../../ui/ModalBox";
import {
  RegisterFeedbackModalContainer,
  RegisterFeedbackModalTextWrapper,
} from "./styles";
import { useTheme } from "styled-components";
import { PrimaryButton } from "../../ui/PrimaryButton";
import { useLanguage } from "../../../hooks/useLanguage";
import { useRouter } from "../../../hooks/useRouter";

interface RegisterFeedbackModalProps extends ModalBoxProps {}

export const RegisterFeedbackModal = ({
  open,
  setOpen,
  ...props
}: RegisterFeedbackModalProps) => {
  const theme = useTheme();
  const { navigation, routesNames } = useRouter();
  const { textData } = useLanguage()

  const onButtonPress = () => {
    setOpen(false);
    navigation.navigate(routesNames.auth.Login);
  }

  return (
    <ModalBox
      open={open}
      setOpen={setOpen}
      modalProps={{
        style: {
          padding: "5%",
        },
      }}
      {...props}
    >
      <RegisterFeedbackModalContainer>
        <RegisterFeedbackModalTextWrapper>
          <BaseText size="sm" color={theme.colors.text_black} weight="medium">
            {textData.registerScreen.registerFeedback.title}
          </BaseText>
          <BaseText size="xs" color={theme.colors.text_muted} weight="medium">
            {textData.registerScreen.registerFeedback.subtitle}
          </BaseText>
        </RegisterFeedbackModalTextWrapper>
        <PrimaryButton onPress={onButtonPress} size="full">
          {textData.registerScreen.registerFeedback.button}
        </PrimaryButton>
      </RegisterFeedbackModalContainer>
    </ModalBox>
  );
};
