
export type TextWeightType = "thin" | "light" | "regular" | "medium" | "bold";

export const parseTextWeight = (textWeight?: TextWeightType): string => {
	let weight = "400Regular"
	
	switch (textWeight) {
		case "thin":
			weight = "100Thin";
			break
		case "light":
			weight = "300Light";
			break
		case "regular":
			weight = "400Regular";
			break
		case "medium":
			weight = "500Medium";
			break
		case "bold":
			weight = "700Bold";
			break
	}

	return `Poppins_${weight}`
};