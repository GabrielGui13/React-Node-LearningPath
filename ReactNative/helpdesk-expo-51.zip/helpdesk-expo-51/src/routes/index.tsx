import { AuthGuard } from "../guards/AuthGuard";
import { AuthRoutes } from "./auth.routes";
import { AppRoutes } from "./app.routes";

export const Routes = () => {
  return (
    <AuthGuard AuthRoutes={<AuthRoutes />}>
      <AppRoutes />
    </AuthGuard>
  );
};
