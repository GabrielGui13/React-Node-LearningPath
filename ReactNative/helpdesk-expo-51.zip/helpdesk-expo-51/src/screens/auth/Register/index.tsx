import { Text } from "react-native";
import { RegisterContainer } from "./styles";

export const Register = () => {
	return (
		<RegisterContainer>
			<Text>Register</Text>
		</RegisterContainer>
	);
}