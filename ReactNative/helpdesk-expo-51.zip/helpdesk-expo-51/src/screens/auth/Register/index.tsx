import { MaterialIcons } from "@expo/vector-icons";
import {
  RegisterContainer,
  RegisterContent,
  RegisterFormWrapper,
  RegisterTitleWrapper,
} from "./styles";
import { Header } from "../../../components/helpers/Header";
import { BaseText } from "../../../components/ui/BaseText";
import { Input } from "../../../components/ui/Input";
import React, { useState } from "react";
import { useLanguage } from "../../../hooks/useLanguage";
import { DismissKeyboard } from "../../../components/helpers/DismissKeyboard";
import { Platform } from "react-native";
import { PrimaryButton } from "../../../components/ui/PrimaryButton";
import { RegisterFeedbackModal } from "../../../components/auth/RegisterFeedbackModal";
import { KeyboardAwareScrollView } from "react-native-keyboard-aware-scroll-view";
import { useTheme } from "styled-components";

export const Register = () => {
  const theme = useTheme();
  const { textData } = useLanguage();
  const [showPassword, setShowPassword] = useState(false);
  const [openRegisterFeedbackModal, setOpenRegisterFeedbackModal] = useState(false);

  return (
    <>
			<Header />
      <KeyboardAwareScrollView
        style={{ flex: 1, backgroundColor: theme.colors.background_light }}
      >
        <DismissKeyboard>
          <RegisterContainer
            contentContainerStyle={{ flexGrow: 1, justifyContent: "center" }}
						alwaysBounceVertical={false}
          >
            <RegisterContent>
              <RegisterFormWrapper>
                <RegisterTitleWrapper>
                  <BaseText size="md">
                    {textData.registerScreen.title}{" "}
                  </BaseText>
                  <BaseText size="md" weight="bold">
                    {textData.registerScreen.titleBold}
                  </BaseText>
                </RegisterTitleWrapper>
                <Input
                  size="full"
                  label={textData.registerScreen.form.name}
                  placeholder={textData.registerScreen.form.namePlaceholder}
                  icon={() => <MaterialIcons name="person-outline" size={22} />}
                />
                <Input
                  size="full"
                  label={textData.registerScreen.form.password}
                  placeholder={textData.registerScreen.form.passwordPlaceholder}
                  icon={() => <MaterialIcons name="lock-outline" size={22} />}
                  showPassword={showPassword}
                  onShowPassword={() => setShowPassword(!showPassword)}
                />
                <Input
                  size="full"
                  label={textData.registerScreen.form.email}
                  placeholder={textData.registerScreen.form.emailPlaceholder}
                  icon={() => <MaterialIcons name="mail-outline" size={22} />}
                />
                <Input
                  size="full"
                  label={textData.registerScreen.form.company}
                  placeholder={textData.registerScreen.form.companyPlaceholder}
                  icon={() => <MaterialIcons name="domain" size={22} />}
                />
                <Input
                  size="full"
                  label={textData.registerScreen.form.businessUnit}
                  placeholder={
                    textData.registerScreen.form.businessUnitPlaceholder
                  }
                  icon={() => <MaterialIcons name="store" size={22} />}
                />
                <Input
                  size="full"
                  label={textData.registerScreen.form.phone}
                  placeholder={textData.registerScreen.form.phonePlaceholder}
                  icon={() => (
                    <MaterialIcons
                      name={
                        Platform.OS === "android"
                          ? "phone-android"
                          : "phone-iphone"
                      }
                      size={22}
                    />
                  )}
                />
              </RegisterFormWrapper>
              <PrimaryButton
                style={{ marginBottom: 40 }}
                size="full"
                onPress={() => setOpenRegisterFeedbackModal((prev) => !prev)}
              >
                {textData.registerScreen.form.button}
              </PrimaryButton>
            </RegisterContent>

            <RegisterFeedbackModal
              open={openRegisterFeedbackModal}
              setOpen={setOpenRegisterFeedbackModal}
            />
          </RegisterContainer>
        </DismissKeyboard>
      </KeyboardAwareScrollView>
    </>
  );
};
