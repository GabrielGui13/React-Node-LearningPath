import styled from "styled-components/native";

export const RegisterTitleWrapper = styled.View`
	flex-direction: row;
	margin-bottom: 15px;
`

export const RegisterContainer = styled.ScrollView`
	flex: 1;
	padding: 5%;
	background-color: ${({ theme }) => theme.colors.background_light};
`

export const RegisterContent = styled.View`
	gap: 30px;
`

export const RegisterFormWrapper = styled.View`
	width: 100%;
`