import { StyleSheet } from "react-native";
import { InviteCodeContainer } from "./styles";
import { Header } from "../../../components/helpers/Header";
import { BaseText } from "../../../components/ui/BaseText";
import { OtpInput } from "react-native-otp-entry";
import { useTheme } from "styled-components";
import { PrimaryButton } from "../../../components/ui/PrimaryButton";
import { DismissKeyboard } from "../../../components/helpers/DismissKeyboard";
import { MessageBox } from "../../../components/ui/MessageBox";

export const InviteCode = () => {
  const theme = useTheme();

  return (
    <>
      <Header />
      <DismissKeyboard>
        <InviteCodeContainer>
          <BaseText align="center" style={{ width: "80%" }}>
            Digite o código convite enviado para o seu e-mail corporativo.
          </BaseText>
          <OtpInput
            numberOfDigits={4}
            focusColor={theme.colors.primary_light}
            theme={{
              pinCodeContainerStyle: styles.pinCodeContainer,
              containerStyle: styles.container,
            }}
          />
          <BaseText align="center" style={{ width: "80%" }} size="sm">
            Caso o código não funcione, fale com o responsável pelo convite.
          </BaseText>
          <PrimaryButton size={"full"} style={{ marginTop: 20 }}>Continuar</PrimaryButton>
          <MessageBox
            type="warning"
            title="Atenção!"
            subtitle={
              "A Interas não solicita seu código via e-mail, SMS, telefone ou Whatsapp."
            }
            message={"Nunca compartilhe seu código de acesso!"}
						textColor="#000"
						iconColor="#000"
          />
        </InviteCodeContainer>
      </DismissKeyboard>
    </>
  );
};

const styles = StyleSheet.create({
  container: {
    justifyContent: "center",
    gap: 10,
  },
  pinCodeContainer: {
    width: 60,
    height: 60,
  },
});
