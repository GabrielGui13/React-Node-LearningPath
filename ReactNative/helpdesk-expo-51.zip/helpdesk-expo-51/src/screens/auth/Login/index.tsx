import { Text } from "react-native";
import { LoginContainer, LoginText } from "./styles";

export const Login = () => {
  return (
    <LoginContainer>
      <LoginText>Login Screen</LoginText>
    </LoginContainer>
  );
};
