import { Text } from "react-native";
import { CodeGeneratorContainer } from "./styles";

export const CodeGenerator = () => {
	return (
		<CodeGeneratorContainer>
			<Text>Gerar código de acesso</Text>
		</CodeGeneratorContainer>
	);
}