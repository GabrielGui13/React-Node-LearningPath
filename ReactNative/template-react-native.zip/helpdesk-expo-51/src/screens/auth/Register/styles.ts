import styled from "styled-components/native";

export const RegisterContainer = styled.View`
	flex: 1;
	background-color: #fff;
	align-items: center;
	justify-content: center;
`