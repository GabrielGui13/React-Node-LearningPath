import { Text } from "react-native";
import { InviteCodeContainer } from "./styles";

export const InviteCode = () => {
	return (
		<InviteCodeContainer>
			<Text>Entrar com código de convite</Text>
		</InviteCodeContainer>
	);
}