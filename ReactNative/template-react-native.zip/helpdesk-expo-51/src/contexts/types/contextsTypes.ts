import { ReactNode } from "react";

export type ContextsProviderProps = {
	children: ReactNode;
}